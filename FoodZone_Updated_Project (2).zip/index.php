
<!DOCTYPE html>
<html>
<head>
    <title>Online Food Ordering</title>
</head>
<body>
    <h2>Welcome to Our Online Food Delivery Service</h2>
    <a href="menu.php">View Menu</a>
</body>
</html>
