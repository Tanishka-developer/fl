
<?php
include 'db.php';
$result = mysqli_query($conn, "SELECT * FROM menu_items");
echo "<h2>Menu</h2>";
echo "<ul>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<li>" . $row['name'] . " - ₹" . $row['price'] . "</li>";
}
echo "</ul>";
?>
<a href="order.php">Place an Order</a>
