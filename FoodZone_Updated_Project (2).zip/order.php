
<!DOCTYPE html>
<html>
<head><title>Place Order</title></head>
<body>
<h2>Order Form</h2>
<form action="submit_order.php" method="POST">
    <input type="text" name="customer_name" placeholder="Your Name" required><br><br>
    <input type="text" name="item_name" placeholder="Dish Name" required><br><br>
    <input type="number" name="quantity" placeholder="Quantity" required><br><br>
    <input type="submit" value="Submit Order">
</form>
</body>
</html>
