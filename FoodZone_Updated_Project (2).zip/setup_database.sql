
CREATE TABLE menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    price DECIMAL(6,2)
);

INSERT INTO menu_items (name, price) VALUES
('Masala Dosa', 80.00),
('Idli Sambhar', 50.00),
('Veg Chowmein', 70.00),
('Manchurian', 90.00);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100),
    item_name VARCHAR(100),
    quantity INT,
    order_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
