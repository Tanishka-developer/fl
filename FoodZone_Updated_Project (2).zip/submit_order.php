
<?php
include 'db.php';

$name = $_POST['customer_name'];
$item = $_POST['item_name'];
$qty = $_POST['quantity'];

$sql = "INSERT INTO orders (customer_name, item_name, quantity) VALUES ('$name', '$item', '$qty')";

if (mysqli_query($conn, $sql)) {
    echo "Order placed successfully!";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
